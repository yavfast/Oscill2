oscill.exe reset


